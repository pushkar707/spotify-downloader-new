const express = require("express")
const cors = require("cors");
const serverless = require("serverless-http")

const app = express();

app.use(express.json())
app.use(cors())

app.get("/test", (req, res) => {
    return res.json({ status: true, message: "API Working nicely" });
})

module.exports.handler = serverless(app)
// app.listen(3000)